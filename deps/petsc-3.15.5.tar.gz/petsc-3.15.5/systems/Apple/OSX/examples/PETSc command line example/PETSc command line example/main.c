//
//  main.c
//  PETSc command line example
//
//  Created by Barry Smith on 8/2/12.
//  Copyright (c) 2012 Barry Smith. All rights reserved.
//

#define PETSC_APPLE_FRAMEWORK

#include "../../../../../../src/snes/tutorials/ex19.c"
